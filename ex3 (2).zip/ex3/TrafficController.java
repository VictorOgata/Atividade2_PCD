import java.util.concurrent.Semaphore;

public class TrafficController {

    Semaphore sem = new Semaphore(1, true);

    public void enterLeft() {
        try {
            sem.acquire();
        } catch (InterruptedException e) {
            System.out.println("erro");
        }
    }

    public void enterRight() {
        try {
            sem.acquire();
        } catch (InterruptedException e) {
            System.out.println("erro");
        }
    }

    public void leaveLeft() {
        sem.release();
    }

    public void leaveRight() {
        sem.release();
    }
}